import React from 'react';
import { useNavigate } from 'react-router-dom';

function AgeSelection() {
  const navigate = useNavigate();

  const handleAgeSelect = (ageGroup) => {
    localStorage.setItem('ageGroup', ageGroup);
    navigate('/quiz');
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-b from-blue-100 to-blue-300">
      <h2 className="text-4xl font-bold text-gray-800 mb-8">Select Your Age Group</h2>
      <div className="grid grid-cols-2 gap-6">
        {['5-10', '11-20', '21-30', '31+'].map((age) => (
          <button
            key={age}
            onClick={() => handleAgeSelect(age)}
            className="px-8 py-4 bg-gradient-to-r from-green-400 to-green-600 text-white text-lg font-semibold rounded-xl shadow-md transform transition duration-300 hover:scale-105 hover:from-green-500 hover:to-green-700"
          >
            {age}
          </button>
        ))}
      </div>
      <p className="mt-8 text-gray-600 italic">Your selected age group customizes the quiz experience.</p>
    </div>
  );
}

export default AgeSelection;