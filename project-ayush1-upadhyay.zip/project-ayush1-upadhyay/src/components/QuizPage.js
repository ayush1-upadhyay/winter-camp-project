// File: src/components/QuizPage.js
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const questionsByAgeGroup = {
  "5-10": [
    {
      question: "What color is the sky?",
      options: ["Blue", "Green", "Red", "Yellow"],
      answer: "Blue",
    },
    {
      question: "How many legs does a cat have?",
      options: ["2", "4", "6", "8"],
      answer: "4",
    },
    {
      question: 'Which animal says "Moo"?',
      options: ["Dog", "Cat", "Cow", "Sheep"],
      answer: "Cow",
    },
    {
      question: "What shape is a football?",
      options: ["Square", "Circle", "Oval", "Triangle"],
      answer: "Oval",
    },
    {
      question: "What do bees make?",
      options: ["Milk", "Honey", "Juice", "Butter"],
      answer: "Honey",
    },
    {
      question: "Which is a fruit?",
      options: ["Carrot", "Potato", "Apple", "Broccoli"],
      answer: "Apple",
    },
    {
      question: "Which season is cold?",
      options: ["Summer", "Winter", "Spring", "Autumn"],
      answer: "Winter",
    },
    { question: "What is 2 + 2?", options: ["3", "4", "5", "6"], answer: "4" },
    {
      question: "Which is bigger?",
      options: ["Elephant", "Mouse", "Ant", "Bee"],
      answer: "Elephant",
    },
    {
      question: "What is used to write?",
      options: ["Spoon", "Pen", "Fork", "Eraser"],
      answer: "Pen",
    },
  ],
  "11-20": [
    {
      question: "What comes next in the sequence: 2, 4, 8, 16, ...?",
      options: ["18", "24", "32", "64"],
      answer: "32",
    },
    {
      question: "Which shape has three sides?",
      options: ["Square", "Triangle", "Circle", "Hexagon"],
      answer: "Triangle",
    },
    { question: "Solve: 15 - 7", options: ["8", "9", "7", "6"], answer: "8" },
    {
      question: "What planet do we live on?",
      options: ["Mars", "Venus", "Earth", "Jupiter"],
      answer: "Earth",
    },
    {
      question: "Water freezes at?",
      options: ["0°C", "50°C", "100°C", "10°C"],
      answer: "0°C",
    },
    {
      question: "What gas do plants breathe in?",
      options: ["Oxygen", "Carbon Dioxide", "Nitrogen", "Helium"],
      answer: "Carbon Dioxide",
    },
    {
      question: "What is H2O?",
      options: ["Salt", "Water", "Air", "Fire"],
      answer: "Water",
    },
    {
      question: "Which is a mammal?",
      options: ["Shark", "Frog", "Whale", "Lizard"],
      answer: "Whale",
    },
    {
      question: "Who invented the light bulb?",
      options: ["Newton", "Einstein", "Edison", "Tesla"],
      answer: "Edison",
    },
    {
      question: "How many continents are there?",
      options: ["5", "6", "7", "8"],
      answer: "7",
    },
  ],
  "21-30": [
    {
      question: "What is the capital of France?",
      options: ["Paris", "London", "Berlin", "Madrid"],
      answer: "Paris",
    },
    {
      question: "What is 9 x 9?",
      options: ["81", "72", "99", "90"],
      answer: "81",
    },
    {
      question: "What is the boiling point of water?",
      options: ["100°C", "90°C", "50°C", "120°C"],
      answer: "100°C",
    },
    {
      question: "Who wrote Hamlet?",
      options: ["Shakespeare", "Hemingway", "Twain", "Dickens"],
      answer: "Shakespeare",
    },
    {
      question: "Which gas is used in balloons?",
      options: ["Oxygen", "Hydrogen", "Helium", "Carbon"],
      answer: "Helium",
    },
    {
      question: "Who painted Mona Lisa?",
      options: ["Da Vinci", "Picasso", "Van Gogh", "Michelangelo"],
      answer: "Da Vinci",
    },
    { question: "Solve: √49", options: ["6", "7", "8", "9"], answer: "7" },
    {
      question: "Fastest land animal?",
      options: ["Lion", "Cheetah", "Horse", "Tiger"],
      answer: "Cheetah",
    },
    {
      question: "Smallest prime number?",
      options: ["0", "1", "2", "3"],
      answer: "2",
    },
    {
      question: "Largest ocean?",
      options: ["Atlantic", "Pacific", "Indian", "Arctic"],
      answer: "Pacific",
    },
  ],
  "31+": [
    {
      question: "What is the square root of 144?",
      options: ["10", "11", "12", "13"],
      answer: "12",
    },
    {
      question: "Who discovered gravity?",
      options: ["Newton", "Einstein", "Galileo", "Tesla"],
      answer: "Newton",
    },
    {
      question: "Which year did WWII end?",
      options: ["1940", "1945", "1950", "1939"],
      answer: "1945",
    },
    {
      question: "Chemical symbol for Gold?",
      options: ["Ag", "Au", "Gd", "Go"],
      answer: "Au",
    },
    {
      question: "Capital of Japan?",
      options: ["Tokyo", "Beijing", "Seoul", "Bangkok"],
      answer: "Tokyo",
    },
    {
      question: "Pi value (approx)?",
      options: ["3.14", "3.15", "3.16", "3.13"],
      answer: "3.14",
    },
    {
      question: "Tallest mountain?",
      options: ["K2", "Everest", "Kangchenjunga", "Denali"],
      answer: "Everest",
    },
    {
      question: "Who invented the telephone?",
      options: ["Bell", "Tesla", "Edison", "Newton"],
      answer: "Bell",
    },
    {
      question: "Which metal is liquid?",
      options: ["Iron", "Mercury", "Gold", "Silver"],
      answer: "Mercury",
    },
    {
      question: "Speed of light?",
      options: ["300,000 km/s", "150,000 km/s", "100,000 km/s", "400,000 km/s"],
      answer: "300,000 km/s",
    },
  ],
};


function QuizPage() {
   const [currentQuestion, setCurrentQuestion] = useState(0);
   const [selectedOption, setSelectedOption] = useState('');
   const [score, setScore] = useState(0);
   const navigate = useNavigate();
   const ageGroup = localStorage.getItem('ageGroup');
   const questions = questionsByAgeGroup[ageGroup] || [];
 
   const handleAnswer = () => {
     if (selectedOption === questions[currentQuestion].answer) {
       setScore(score + 1);
     }
     const nextQuestion = currentQuestion + 1;
     if (nextQuestion < questions.length) {
       setCurrentQuestion(nextQuestion);
       setSelectedOption('');
     } else {
       localStorage.setItem('score', score);
       navigate('/result');
     }
   };
 
   return (
     <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-b from-purple-400 via-pink-500 to-red-500 p-6">
       <div className="w-full max-w-2xl bg-white shadow-lg rounded-lg p-8">
         <h2 className="text-3xl font-bold text-gray-800 mb-6 text-center">{questions[currentQuestion]?.question}</h2>
         <div className="flex flex-col gap-4">
           {questions[currentQuestion]?.options.map((option, index) => (
             <label key={index} className="flex items-center p-4 bg-gray-100 rounded-lg shadow-sm cursor-pointer hover:bg-gray-200">
               <input
                 type="radio"
                 name="option"
                 value={option}
                 checked={selectedOption === option}
                 onChange={() => setSelectedOption(option)}
                 className="w-5 h-5 mr-3 text-purple-600 focus:ring-purple-500"
               />
               <span className="text-lg text-gray-700">{option}</span>
             </label>
           ))}
         </div>
         <button
           onClick={handleAnswer}
           disabled={!selectedOption}
           className="mt-6 w-full py-3 bg-purple-600 text-white font-semibold rounded-lg shadow-md hover:bg-purple-700 disabled:opacity-50"
         >
           Submit Answer
         </button>
       </div>
     </div>
   );
 }
 
 export default QuizPage;