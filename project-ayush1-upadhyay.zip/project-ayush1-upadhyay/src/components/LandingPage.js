import React from 'react';
import { useNavigate } from 'react-router-dom';

function LandingPage() {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <h1 className="text-4xl font-bold text-blue-600 mb-4">Blockchain IQ Calculator</h1>
      <p className="text-lg text-gray-700 mb-6">Test your intelligence and secure your score on the blockchain!</p>
      <button onClick={() => navigate('/age')} className="px-6 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">Start Test</button>
    </div>
  );
}

export default LandingPage;